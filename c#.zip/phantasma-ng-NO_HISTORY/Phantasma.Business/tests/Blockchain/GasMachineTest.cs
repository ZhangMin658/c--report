﻿namespace Phantasma.Business.Tests;

public class GasMachineTest
{
    
}
