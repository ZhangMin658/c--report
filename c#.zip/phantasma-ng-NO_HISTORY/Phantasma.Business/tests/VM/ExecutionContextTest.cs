﻿using Xunit;

namespace Phantasma.Business.Tests.VM;

public class ExecutionContextTest
{
    [Fact]
    public void test_something()
    {
        
    }
}
