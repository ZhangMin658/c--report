﻿using Phantasma.Core;
using Xunit;

namespace Phantasma.Business.Tests.VM;

public class ExecutionFrameTest
{
    
    private ExecutionFrame ExecutionFrame;

    private void Init()
    {
        //ExecutionFrame = new ExecutionFrame();
    }
    
    [Fact]
    public void get_test_register()
    {
        //ExecutionFrame.GetRegister();
    }
}
