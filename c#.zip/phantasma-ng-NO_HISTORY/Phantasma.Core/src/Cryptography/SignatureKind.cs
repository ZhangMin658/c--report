﻿namespace Phantasma.Core
{
    public enum SignatureKind
    {
        None,
        Ed25519,
        ECDSA
    }
}
