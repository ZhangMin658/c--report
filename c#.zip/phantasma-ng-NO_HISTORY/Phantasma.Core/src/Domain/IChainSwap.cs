namespace Phantasma.Core;

public interface IChainSwap
{
}
