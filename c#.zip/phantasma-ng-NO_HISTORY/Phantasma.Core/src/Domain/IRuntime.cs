using System.Numerics;
using Phantasma.Core.Context;
using Phantasma.Shared.Types;

namespace Phantasma.Core
{
    public interface IRuntime
    {
        IChain Chain { get; }
        Transaction Transaction { get; }
        public Timestamp Time { get; }
        public StorageContext Storage { get; }
        public StorageContext RootStorage { get; }
        public bool IsTrigger { get; }
        public int TransactionIndex { get; }

        public IChainTask CurrentTask { get; }

        ExecutionContext CurrentContext { get; }
        ExecutionContext PreviousContext { get; }

        public Address GasTarget { get; }
        BigInteger UsedGas { get; }
        public BigInteger GasPrice { get; }

        public Block GetBlockByHash(Hash hash);
        public Block GetBlockByHeight(BigInteger height);

        public Address GetValidator(Timestamp time);

        public bool HasGenesis { get; }
        public string NexusName { get; }
        public uint ProtocolVersion { get; }
        public Address GenesisAddress { get; }
        public Hash GenesisHash { get; }
        public Timestamp GetGenesisTime();

        public Transaction GetTransaction(Hash hash);

        public string[] GetTokens();
        public string[] GetChains();
        public string[] GetPlatforms();
        public string[] GetFeeds();
        public string[] GetOrganizations();
        
        // returns contracts deployed on current chain
        public IContract[] GetContracts();

        public IToken GetToken(string symbol);
        public Hash GetTokenPlatformHash(string symbol, IPlatform platform);
        public IFeed GetFeed(string name);
        public IContract GetContract(string name);
        public Address GetContractOwner(Address address);

        public IPlatform GetPlatformByName(string name);
        public IPlatform GetPlatformByIndex(int index);

        public bool TokenExists(string symbol);
        public bool NFTExists(string symbol, BigInteger tokenID);
        public bool FeedExists(string name);
        public bool PlatformExists(string name);

        public bool OrganizationExists(string name);
        public IOrganization GetOrganization(string name);

        public bool AddMember(string organization, Address admin, Address target);
        public bool RemoveMember(string organization, Address admin, Address target);
        public void MigrateMember(string organization, Address admin, Address source, Address destination);

        public bool ContractExists(string name);
        public bool ContractDeployed(string name);

        public bool ArchiveExists(Hash hash);
        public IArchive GetArchive(Hash hash);
        public bool DeleteArchive(Hash hash);

        public bool AddOwnerToArchive(Hash hash, Address address);

        public bool RemoveOwnerFromArchive(Hash hash, Address address);

        public bool WriteArchive(IArchive archive, int blockIndex, byte[] data);

        public bool ChainExists(string name);
        public IChain GetChainByAddress(Address address);
        public IChain GetChainByName(string name);
        public int GetIndexOfChain(string name);

        public IChain GetChainParent(string name);

        public void Log(string description);
        public void Throw(string description);
        void Expect(bool condition, string description);
        public void Notify(EventKind kind, Address address, byte[] data);
        public VMObject CallContext(string contextName, uint jumpOffset, string methodName, params object[] args);
        public VMObject CallInterop(string methodName, params object[] args);

        public Address LookUpName(string name);
        public bool HasAddressScript(Address from);
        public byte[] GetAddressScript(Address from);
        public string GetAddressName(Address from);

        public Event[] GetTransactionEvents(Hash transactionHash);
        public Hash[] GetTransactionHashesForAddress(Address address);

        public ValidatorEntry GetValidatorByIndex(int index);
        public ValidatorEntry[] GetValidators();
        public bool IsPrimaryValidator(Address address);
        public bool IsSecondaryValidator(Address address);
        public int GetPrimaryValidatorCount();
        public int GetSecondaryValidatorCount();
        public bool IsKnownValidator(Address address);

        public bool IsStakeMaster(Address address); // TODO remove
        public BigInteger GetStake(Address address);

        public BigInteger GetTokenPrice(string symbol);
        public BigInteger GetGovernanceValue(string name);

        public BigInteger GenerateUID();
        public BigInteger GenerateRandomNumber();

        public TriggerResult InvokeTrigger(bool allowThrow, byte[] script, string contextName, ContractInterface abi, string triggerName, params object[] args);

        public bool IsWitness(Address address);

        public BigInteger GetBalance(string symbol, Address address);
        public BigInteger[] GetOwnerships(string symbol, Address address);
        public BigInteger GetTokenSupply(string symbol);

        public void CreateToken(Address owner, string symbol, string name, BigInteger maxSupply, int decimals, TokenFlags flags, byte[] script, ContractInterface abi);
        public void SetPlatformTokenHash(string symbol, string platform, Hash hash);
        public void CreateChain(Address creator, string organization, string name, string parentChain);
        public void CreateFeed(Address owner, string name, FeedMode mode);
        public IArchive CreateArchive(MerkleTree merkleTree, Address owner, string name, BigInteger size, Timestamp time, IArchiveEncryption encryption);

        public BigInteger CreatePlatform(Address from, string name, string externalAddress, Address interopAddress, string fuelSymbol);

        public bool IsAddressOfParentChain(Address address);
        public bool IsAddressOfChildChain(Address address);

        public bool IsPlatformAddress(Address address);
        public void RegisterPlatformAddress(string platform, Address localAddress, string externalAddress);

        public void MintTokens(string symbol, Address from, Address target, BigInteger amount);
        public void BurnTokens(string symbol, Address from, BigInteger amount);
        public void TransferTokens(string symbol, Address source, Address destination, BigInteger amount);
        public void SwapTokens(string sourceChain, Address from, string targetChain, Address to, string symbol, BigInteger value);

        public BigInteger MintToken(string symbol, Address from, Address target, byte[] rom, byte[] ram, BigInteger seriesID);
        public void BurnToken(string symbol, Address from, BigInteger tokenID);
        public void InfuseToken(string symbol, Address from, BigInteger tokenID, string infuseSymbol, BigInteger value);
        public void TransferToken(string symbol, Address source, Address destination, BigInteger tokenID);
        public void WriteToken(Address from, string tokenSymbol, BigInteger tokenID, byte[] ram);
        public TokenContent ReadToken(string tokenSymbol, BigInteger tokenID);
        public ITokenSeries CreateTokenSeries(string tokenSymbol, Address from, BigInteger seriesID, BigInteger maxSupply, TokenSeriesMode mode, byte[] script, ContractInterface abi);
        public ITokenSeries GetTokenSeries(string symbol, BigInteger seriesID);

        public byte[] ReadOracle(string URL);

        public IChainTask StartTask(Address from, string contractName, ContractMethod method, uint frequency, uint delay, TaskFrequencyMode mode, BigInteger gasLimit);
        public void StopTask(IChainTask task);
        public IChainTask GetTask(BigInteger taskID);

        TriggerResult InvokeTriggerOnAccount(bool allowThrow, Address address, AccountTrigger trigger, params object[] args);
        TriggerResult InvokeTriggerOnToken(bool allowThrow, IToken token, TokenTrigger trigger, params object[] args);
        void AddAllowance(Address destination, string symbol, BigInteger amount);
        bool SubtractAllowance(Address destination, string symbol, BigInteger amount);
        void RemoveAllowance(Address destination, string symbol);
    }
}
