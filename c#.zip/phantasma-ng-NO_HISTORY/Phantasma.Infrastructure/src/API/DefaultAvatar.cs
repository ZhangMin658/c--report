﻿namespace Phantasma.Infrastructure
{
    public static class DefaultAvatar
    {
        public readonly static string Data = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgBAMAAACBVGfHAAAAJFBMVEWcnJz////39/etra3e3t6lpaW1tbXn5+fW1tbv7+/Ozs69vb2ss4cPAAAAk0lEQVQoz2OgJWA2QOWnKAqVIfM5BIGgAUlgIUhAAsFnEwSDBLgAC0SgAC7ABBEQhQsYQgSEMQRwa2GHGopu7QaEQxpBfBF0pzsg+3WioKAkkn9ZHcFaAuACRhBDleEaFCECQjBNQYJQoAoVcIQJiCA5Cx4iCIcjHB+IEBCFBigcSMHMRDV1IkJAEiygiBAQYmAAABD5F4JgcTScAAAAAElFTkSuQmCC";
    }
}
