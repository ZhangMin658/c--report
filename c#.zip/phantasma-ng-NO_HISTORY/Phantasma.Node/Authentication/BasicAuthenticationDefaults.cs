﻿namespace Phantasma.Node.Authentication;

public class BasicAuthenticationDefaults
{
    public const string AuthenticationScheme = "Basic";
}
