﻿namespace Phantasma.Node.Events;

public class InvalidateEndpointCacheEvent
{
    public string Tag { get; set; }
}
