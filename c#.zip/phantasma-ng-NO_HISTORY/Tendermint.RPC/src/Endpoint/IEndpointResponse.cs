﻿namespace Tendermint.RPC.Endpoint
{
    public interface IEndpointResponse
    {
    }
}
