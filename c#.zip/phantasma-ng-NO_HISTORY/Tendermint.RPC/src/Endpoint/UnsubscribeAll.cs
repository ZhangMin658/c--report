﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Tendermint.RPC.Endpoint
{
    /// <summary>
    /// Websocket API
    /// </summary>
    public class UnsubscribeAll
    {
    }
}
