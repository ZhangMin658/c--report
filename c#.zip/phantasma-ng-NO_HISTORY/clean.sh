#!/bin/bash

rm --force -r .vs
rm --force -r Phantasma.Business/src/bin
rm --force -r Phantasma.Business/src/obj
rm --force -r Phantasma.Core/src/bin
rm --force -r Phantasma.Core/src/obj
rm --force -r Phantasma.Core.Tests/bin
rm --force -r Phantasma.Core.Tests/obj
rm --force -r Phantasma.Infrastructure/src/bin
rm --force -r Phantasma.Infrastructure/src/obj
rm --force -r Phantasma.Shared/src/bin
rm --force -r Phantasma.Shared/src/obj
rm --force -r Phantasma.Node/bin
rm --force -r Phantasma.Node/obj
rm --force -r Phantasma.Tests/bin
rm --force -r Phantasma.Tests/obj
rm --force -r Phantasma.Tests/Phantasma.Simulator/bin
rm --force -r Phantasma.Tests/Phantasma.Simulator/obj
rm --force -r Tendermint/bin
rm --force -r Tendermint/obj
rm --force -r Tendermint.RPC/bin
rm --force -r Tendermint.RPC/obj

