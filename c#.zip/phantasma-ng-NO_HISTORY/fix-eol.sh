#!/bin/bash

find ./ -name "*.cs" -exec dos2unix --keepdate --keep-bom {} +